import { Router } from 'express';

const router = Router();

// router.use('/auth/user', userAuthRoutes);

export default router;